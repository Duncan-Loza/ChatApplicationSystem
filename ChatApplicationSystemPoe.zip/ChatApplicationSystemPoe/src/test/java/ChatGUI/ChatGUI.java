package com.mycompany.chatapplicationsystempoe;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class ChatGUI extends JFrame {

    private Login login = new Login();
    private int messageNumber = 1;
    private boolean isLoggedIn = false;
    private JLabel statusLabel;

    public ChatGUI() {

        // ===== FRAME SETUP =====
        setTitle("QuickChat System");
        setSize(520, 560);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // ===== MAIN PANEL =====
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Color.WHITE);

        // ===== TITLE =====
        JLabel title = new JLabel("QuickChat System", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        mainPanel.add(title, BorderLayout.NORTH);

        // ===== BUTTON PANEL =====
        JPanel buttons = new JPanel(new GridLayout(7, 1, 8, 8));
        buttons.setBackground(Color.WHITE);

        JButton registerBtn = createButton("Register");
        JButton loginBtn = createButton("Login");
        JButton sendBtn = createButton("Send Message");
        JButton storeBtn = createButton("Store Message");
        JButton reportBtn = createButton("View Report");
        JButton searchBtn = createButton("Search Message");
        JButton deleteBtn = createButton("Delete Message");

        buttons.add(registerBtn);
        buttons.add(loginBtn);
        buttons.add(sendBtn);
        buttons.add(storeBtn);
        buttons.add(reportBtn);
        buttons.add(searchBtn);
        buttons.add(deleteBtn);

        mainPanel.add(buttons, BorderLayout.CENTER);

        // ===== STATUS =====
        statusLabel = new JLabel("Please register or login to continue", SwingConstants.CENTER);
        mainPanel.add(statusLabel, BorderLayout.SOUTH);

        setContentPane(mainPanel);

        // ===== ACTIONS =====
        registerBtn.addActionListener(e -> registerUser());
        loginBtn.addActionListener(e -> loginUser());

        sendBtn.addActionListener(e -> {
            if (!isLoggedIn) show("Login first!");
            else sendMessage();
        });

        storeBtn.addActionListener(e -> {
            if (!isLoggedIn) show("Login first!");
            else storeMessage();
        });

        reportBtn.addActionListener(e -> showReport());
        searchBtn.addActionListener(e -> searchMessage());
        deleteBtn.addActionListener(e -> deleteMessage());

        // ===== FINAL SHOW (CRITICAL FIX) =====
        setVisible(true);
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        return btn;
    }

    private void show(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }

    // ================= FEATURES =================

    private void registerUser() {
        JTextField first = new JTextField();
        JTextField last = new JTextField();
        JTextField user = new JTextField();
        JTextField phone = new JTextField();
        JPasswordField pass = new JPasswordField();

        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("First Name")); panel.add(first);
        panel.add(new JLabel("Last Name")); panel.add(last);
        panel.add(new JLabel("Username")); panel.add(user);
        panel.add(new JLabel("Phone")); panel.add(phone);
        panel.add(new JLabel("Password")); panel.add(pass);

        int result = JOptionPane.showConfirmDialog(this, panel,
                "Register", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            User u = new User();
            u.setFirstName(first.getText());
            u.setLastName(last.getText());
            u.setUsername(user.getText());
            u.setPhoneNumber(phone.getText());

            String msg = login.registerUser(u, new String(pass.getPassword()));
            JOptionPane.showMessageDialog(this, msg);
        }
    }

    private void loginUser() {
        JTextField user = new JTextField();
        JPasswordField pass = new JPasswordField();

        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(new JLabel("Username")); panel.add(user);
        panel.add(new JLabel("Password")); panel.add(pass);

        int result = JOptionPane.showConfirmDialog(this, panel,
                "Login", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            User u = login.loginUser(user.getText(), new String(pass.getPassword()));
            String msg = login.loginMessage(u);

            isLoggedIn = (u != null);
            statusLabel.setText(isLoggedIn ? "Logged in as " + u.getUsername() : "Login failed");

            JOptionPane.showMessageDialog(this, msg);
        }
    }

    private void sendMessage() {
        JTextField recipient = new JTextField();
        JTextArea message = new JTextArea(3, 20);

        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(new JLabel("Recipient")); panel.add(recipient);
        panel.add(new JLabel("Message")); panel.add(new JScrollPane(message));

        int result = JOptionPane.showConfirmDialog(this, panel,
                "Send Message", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            Message m = new Message(messageNumber++,
                    recipient.getText(), message.getText());

            JOptionPane.showMessageDialog(this, m.sendMessage());
        }
    }

    private void storeMessage() {
        JTextField recipient = new JTextField();
        JTextArea message = new JTextArea(3, 20);

        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(new JLabel("Recipient")); panel.add(recipient);
        panel.add(new JLabel("Message")); panel.add(new JScrollPane(message));

        int result = JOptionPane.showConfirmDialog(this, panel,
                "Store Message", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            Message m = new Message(messageNumber++,
                    recipient.getText(), message.getText());

            JOptionPane.showMessageDialog(this, m.storeMessage());
        }
    }

    private void showReport() {
        JTextArea area = new JTextArea(Message.displayReport());
        area.setEditable(false);

        JOptionPane.showMessageDialog(this, new JScrollPane(area));
    }

    private void searchMessage() {
        String recipient = JOptionPane.showInputDialog(this, "Enter recipient:");
        if (recipient != null) {
            JOptionPane.showMessageDialog(this,
                    Message.searchRecipient(recipient));
        }
    }

    private void deleteMessage() {
        String hash = JOptionPane.showInputDialog(this, "Enter message hash:");
        if (hash != null) {
            JOptionPane.showMessageDialog(this,
                    Message.deleteMessage(hash));
        }
    }
}