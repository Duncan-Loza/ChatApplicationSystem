package com.mycompany.chatapplicationsystempoe;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageJUnitTest {

    @Test
    public void testSentMessagesArrayPopulated() {

        Message.reset();

        Message m1 = new Message(1, "+27834557896", "Did you get the cake?");
        m1.sendMessage();

        Message m2 = new Message(2, "+27888888888", "It is dinner time !");
        m2.sendMessage();

        String result = Message.printMessages();

        assertTrue(result.contains("Did you get the cake?"));
        assertTrue(result.contains("It is dinner time !"));
    }

    @Test
    public void testLongestMessage() {

        Message.reset();

        Message m1 = new Message(1, "+27834557896", "Did you get the cake?");
        m1.storeMessage();

        Message m2 = new Message(2, "+27838884567",
                "Where are you? You are late! I have asked you to be on time.");
        m2.storeMessage();

        assertEquals(
                "Where are you? You are late! I have asked you to be on time.",
                Message.getLongestStoredMessage()
        );
    }

    @Test
    public void testSearchMessageID() {

        Message.reset();

        Message m = new Message(4, "+2788884567", "It is dinner time !");
        m.storeMessage();

        assertTrue(
                Message.searchMessageID(m.getMessageID())
                        .contains("It is dinner time !")
        );
    }

    @Test
    public void testSearchRecipient() {

        Message.reset();

        Message m1 = new Message(1, "+27838884567",
                "Where are you? You are late! I have asked you to be on time.");
        m1.storeMessage();

        Message m2 = new Message(2, "+27838884567",
                "Ok, I am leaving without you.");
        m2.storeMessage();

        String result = Message.searchRecipient("+27838884567");

        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteMessage() {

        Message.reset();

        Message m = new Message(2, "+27811111111",
                "Where are you? You are late! I have asked you to be on time.");

        m.storeMessage();

        String hash = m.getMessageHash();

        String result = Message.deleteMessage(hash);

        assertTrue(result.contains("deleted"));
    }

    @Test
    public void testDisplayReport() {

        Message.reset();

        Message m = new Message(1, "+27812345678", "Test message");
        m.storeMessage();

        String report = Message.displayReport();

        assertTrue(report.contains("Message Hash"));
        assertTrue(report.contains("Recipient"));
        assertTrue(report.contains("Message"));
    }
}