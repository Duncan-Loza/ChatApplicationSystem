package com.mycompany.chatapplicationsystempoe;

import java.util.ArrayList;

public class Message {

    private final int messageNumber;
    private final String recipient;
    private final String messageText;

    private final String messageID;
    private final String messageHash;

    private String status;

    private static int totalMessages = 0;

    private static final ArrayList<Message> sentMessages = new ArrayList<>();
    private static final ArrayList<Message> storedMessages = new ArrayList<>();

    // ===== CONSTRUCTOR =====
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;

        this.messageID = generateID();
        this.messageHash = generateHash();
    }

    // ===== GETTERS =====
    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    // ===== RESET (FOR TESTING) =====
    public static void reset() {
        sentMessages.clear();
        storedMessages.clear();
        totalMessages = 0;
    }

    // ===== ID GENERATION =====
    private String generateID() {
        return messageNumber + "-" + (int)(Math.random() * 9000 + 1000);
    }

    // ===== HASH GENERATION =====
    private String generateHash() {

        String safe = (messageText == null || messageText.isBlank())
                ? "EMPTY EMPTY"
                : messageText.trim();

        String[] words = safe.split("\\s+");

        String first = words[0];
        String last = words[words.length - 1];

        return (messageNumber + first + last).toUpperCase();
    }

    // ===== SEND MESSAGE =====
    public String sendMessage() {

        if (messageText == null || messageText.isBlank()) {
            return "Message cannot be empty.";
        }

        if (messageText.length() > 250) {
            return "Message exceeds 250 characters.";
        }

        sentMessages.add(this);
        totalMessages++;
        status = "SENT";

        return "Message sent successfully.";
    }

    // ===== STORE MESSAGE =====
    public String storeMessage() {

        storedMessages.add(this);
        status = "STORED";

        return "Message stored successfully.";
    }

    // ===== PRINT SENT MESSAGES =====
    public static String printMessages() {

        StringBuilder sb = new StringBuilder();

        for (Message m : sentMessages) {
            sb.append(m.messageText).append("\n");
        }

        return sb.length() == 0 ? "No messages sent yet." : sb.toString();
    }

    // ===== SEARCH RECIPIENT =====
    public static String searchRecipient(String recipient) {

        StringBuilder sb = new StringBuilder();

        for (Message m : storedMessages) {
            if (m.recipient.equals(recipient)) {
                sb.append(m.messageText).append("\n");
            }
        }

        return sb.length() == 0 ? "No messages found." : sb.toString();
    }

    // ===== SEARCH MESSAGE ID =====
    public static String searchMessageID(String id) {

        for (Message m : storedMessages) {
            if (m.messageID.equals(id)) {
                return "Recipient: " + m.recipient +
                        "\nMessage: " + m.messageText;
            }
        }

        return "Message ID not found.";
    }

    // ===== DELETE MESSAGE =====
    public static String deleteMessage(String hash) {

        for (int i = 0; i < storedMessages.size(); i++) {

            if (storedMessages.get(i).messageHash.equals(hash)) {
                storedMessages.remove(i);
                return "Message successfully deleted.";
            }
        }

        return "Message hash not found.";
    }

    // ===== LONGEST MESSAGE =====
    public static String getLongestStoredMessage() {

        if (storedMessages.isEmpty()) return "";

        Message longest = storedMessages.get(0);

        for (Message m : storedMessages) {
            if (m.messageText.length() > longest.messageText.length()) {
                longest = m;
            }
        }

        return longest.messageText;
    }

    // ===== REPORT =====
    public static String displayReport() {

        StringBuilder sb = new StringBuilder();
        sb.append("=== MESSAGE REPORT ===\n");

        for (Message m : storedMessages) {
            sb.append("\n-----------------\n");
            sb.append("Message Hash: ").append(m.messageHash).append("\n");
            sb.append("Recipient: ").append(m.recipient).append("\n");
            sb.append("Message: ").append(m.messageText).append("\n");
        }

        return sb.toString();
    }

    // ===== TOTAL =====
    public static int returnTotalMessages() {
        return totalMessages;
    }

    // FIX: prevents your JUnit compile error
    public boolean discardMessage() {
        storedMessages.remove(this);
        sentMessages.remove(this);
        return true;
    }
}