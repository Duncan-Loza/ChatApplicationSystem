package com.mycompany.chatapplicationsystempoe;

import java.util.Scanner;

public class ChatApplicationSystemPoe {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Login login = new Login();

        System.out.println("==================================");
        System.out.println("        Welcome to QuickChat      ");
        System.out.println("==================================");

        // reset arrays for clean run
        Message.reset();

        int choice;

        do {
            System.out.println("\nMain Menu");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose: ");

            while (!input.hasNextInt()) {
                System.out.println("Invalid input.");
                input.nextLine();
            }

            choice = input.nextInt();
            input.nextLine();

            switch (choice) {

                case 1 -> {
                    User user = new User();

                    System.out.print("First name: ");
                    user.setFirstName(input.nextLine());

                    System.out.print("Last name: ");
                    user.setLastName(input.nextLine());

                    System.out.print("Username: ");
                    user.setUsername(input.nextLine());

                    System.out.print("Password: ");
                    String password = input.nextLine();

                    System.out.print("Phone (+27...): ");
                    user.setPhoneNumber(input.nextLine());

                    System.out.println(login.registerUser(user, password));
                }

                case 2 -> {
                    System.out.print("Username: ");
                    String username = input.nextLine();

                    System.out.print("Password: ");
                    String password = input.nextLine();

                    User loggedIn = login.loginUser(username, password);

                    System.out.println(login.loginMessage(loggedIn));

                    if (loggedIn != null) {

                        System.out.print("How many messages? ");
                        int limit = input.nextInt();
                        input.nextLine();

                        int count = 0;

                        while (count < limit) {

                            System.out.println("\n1 Send");
                            System.out.println("2 Discard");
                            System.out.println("3 Store");
                            System.out.println("4 Exit");
                            System.out.print("Choice: ");

                            int option = input.nextInt();
                            input.nextLine();

                            if (option == 4) break;

                            System.out.print("Recipient (+27...): ");
                            String recipient = input.nextLine();

                            System.out.print("Message: ");
                            String text = input.nextLine();

                            Message message = new Message(++count, recipient, text);

                            switch (option) {
                                case 1 -> System.out.println(message.sendMessage());
                                case 2 -> System.out.println(message.discardMessage());
                                case 3 -> System.out.println(message.storeMessage());
                                default -> System.out.println("Invalid option");
                            }
                        }
                    }
                }

                case 3 -> System.out.println("Goodbye!");
            }

        } while (choice != 3);

        input.close();
    }
}