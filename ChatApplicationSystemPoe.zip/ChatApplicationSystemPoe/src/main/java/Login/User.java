package com.mycompany.chatapplicationsystempoe;

public class User {

    private String firstName;
    private String lastName;
    private String username;
    private String phoneNumber;
    private String passwordHash;

    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getUsername() { return username; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getPasswordHash() { return passwordHash; }

    public void setFirstName(String v) { firstName = v; }
    public void setLastName(String v) { lastName = v; }
    public void setUsername(String v) { username = v; }
    public void setPhoneNumber(String v) { phoneNumber = v; }
    public void setPasswordHash(String v) { passwordHash = v; }
}