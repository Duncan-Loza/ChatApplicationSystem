package com.mycompany.chatapplicationsystempoe;

import java.util.ArrayList;
import java.util.List;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

public class Login {

    private final List<User> users = new ArrayList<>();

    public String registerUser(User user, String password) {

        if (user.getUsername() == null || !user.getUsername().contains("_")) {
            return "Invalid username";
        }

        if (password == null || password.length() < 8) {
            return "Password too weak";
        }

        user.setPasswordHash(hash(password));
        users.add(user);

        return "User registered successfully";
    }

    public User loginUser(String username, String password) {

        String hashed = hash(password);

        for (User u : users) {
            if (u.getUsername().equals(username)
                    && u.getPasswordHash().equals(hashed)) {
                return u;
            }
        }

        return null;
    }

    public String loginMessage(User user) {
        return (user != null)
                ? "Welcome " + user.getUsername()
                : "Login failed";
    }

    private String hash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(input.getBytes(StandardCharsets.UTF_8));

            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));

            return sb.toString();
        } catch (Exception e) {
            return input;
        }
    }
}