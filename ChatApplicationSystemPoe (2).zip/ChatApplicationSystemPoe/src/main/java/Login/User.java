/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.chatapplicationsystempoe;

public class User {

   
    // Instance Variables
    
    private String firstName;
    private String lastName;
    private String username;
    private String phoneNumber;
    private String passwordHash;

    
    // Default Constructor
   
    public User() {

    }

    
    // Parameterized Constructor
    
    public User(
            String firstName,
            String lastName,
            String username,
            String phoneNumber
    ) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.phoneNumber = phoneNumber;
    }

   
    // Getter Methods
    

    // Return first name
    public String getFirstName() {

        return firstName;
    }

    // Return last name
    public String getLastName() {

        return lastName;
    }

    // Return username
    public String getUsername() {

        return username;
    }

    // Return phone number
    public String getPhoneNumber() {

        return phoneNumber;
    }

    // Return password hash
    public String getPasswordHash() {

        return passwordHash;
    }

   
    // Setter Methods
  

    // Set first name
    public void setFirstName(String firstName) {

        this.firstName = firstName;
    }

    // Set last name
    public void setLastName(String lastName) {

        this.lastName = lastName;
    }

    // Set username
    public void setUsername(String username) {

        this.username = username;
    }

    // Set phone number
    public void setPhoneNumber(String phoneNumber) {

        this.phoneNumber = phoneNumber;
    }

    // Set password hash
    public void setPasswordHash(String passwordHash) {

        this.passwordHash = passwordHash;
    }

    
    // toString Method
    
    @Override
    public String toString() {

        return "User Details"
                + "\nFirst Name: " + firstName
                + "\nLast Name: " + lastName
                + "\nUsername: " + username
                + "\nPhone Number: " + phoneNumber;
    }
}

