

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.chatapplicationsystempoe;

import java.util.ArrayList;
import java.util.List;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

public class Login {

    
    // ArrayList to Store Registered Users
    
    private final List<User> users;

  
    // Constructor
    
    public Login() {

        users = new ArrayList<>();
    }

    
    // Register User Method
    
    public String registerUser(User user, String password) {

        // Validate username
        if (!checkUsername(user.getUsername())) {

            return "Username is not correctly formatted.\n"
                    + "Username must contain an underscore (_) "
                    + "and may not exceed 5 characters.";
        }

        // Validate password
        if (!checkPassword(password)) {

            return "Password is not correctly formatted.\n"
                    + "Password must contain:\n"
                    + "- At least 8 characters\n"
                    + "- One capital letter\n"
                    + "- One number\n"
                    + "- One special character";
        }

        // Validate phone number
        if (!checkPhoneNumber(user.getPhoneNumber())) {

            return "Phone number incorrectly formatted.\n"
                    + "Phone number must start with +27 "
                    + "followed by 9 digits.";
        }

        // Check if username already exists
        for (User existingUser : users) {

            if (existingUser.getUsername()
                    .equalsIgnoreCase(user.getUsername())) {

                return "Username already exists.";
            }
        }

        // Store hashed password
        user.setPasswordHash(hashPassword(password));

        // Add user to ArrayList
        users.add(user);

        return "User registered successfully.";
    }

    
    // Login User Method
    
    public User loginUser(String username, String password) {

        String hashedPassword = hashPassword(password);

        for (User user : users) {

            if (user.getUsername().equalsIgnoreCase(username)
                    && user.getPasswordHash().equals(hashedPassword)) {

                return user;
            }
        }

        return null;
    }

   
    // Login Status Message
    
    public String loginMessage(User user) {

        if (user != null) {

            return "Welcome "
                    + user.getFirstName()
                    + " "
                    + user.getLastName()
                    + ". It is great to see you again.";
        }

        return "Username or password is incorrect. "
                + "Please try again.";
    }

    
    // Username Validation Method
    
    private boolean checkUsername(String username) {

        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    
    // Password Validation Method
   
    private boolean checkPassword(String password) {

        // Check minimum length
        if (password == null || password.length() < 8) {

            return false;
        }

        boolean hasUppercase = false;
        boolean hasDigit = false;
        boolean hasSpecialCharacter = false;

        // Loop through password characters
        for (char character : password.toCharArray()) {

            if (Character.isUpperCase(character)) {

                hasUppercase = true;

            } else if (Character.isDigit(character)) {

                hasDigit = true;

            } else if (!Character.isLetterOrDigit(character)) {

                hasSpecialCharacter = true;
            }
        }

        return hasUppercase
                && hasDigit
                && hasSpecialCharacter;
    }

    
    // Phone Number Validation Method
    
    private boolean checkPhoneNumber(String phoneNumber) {

        return phoneNumber != null
                && phoneNumber.matches("^\\+27[6-8][0-9]{8}$");
    }

    
    // Password Hashing Method
    
    private String hashPassword(String password) {

        try {

            MessageDigest messageDigest =
                    MessageDigest.getInstance("SHA-256");

            byte[] hashedBytes =
                    messageDigest.digest(
                            password.getBytes(StandardCharsets.UTF_8)
                    );

            StringBuilder hashedPassword =
                    new StringBuilder();

            // Convert bytes to hexadecimal
            for (byte currentByte : hashedBytes) {

                hashedPassword.append(
                        String.format("%02x", currentByte)
                );
            }

            return hashedPassword.toString();

        } catch (NoSuchAlgorithmException exception) {

            throw new RuntimeException(
                    "Error occurred while hashing password."
            );
        }
    }
}



