/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapplicationsystempoe;

import java.util.Scanner;

public class ChatApplicationSystemPoe {

    public static void main(String[] args) {

        try (Scanner input = new Scanner(System.in)) {
            Login login = new Login();
            
            int choice;
            
            // Welcome Message
            System.out.println("==================================");
            System.out.println("        Welcome to QuickChat      ");
            System.out.println("==================================");
            
            do {
                
                // Main Menu
                System.out.println("\nMain Menu");
                System.out.println("1. Register");
                System.out.println("2. Login");
                System.out.println("3. Exit");
                System.out.print("Choose an option: ");
                
                // Validate integer input
                while (!input.hasNextInt()) {
                    System.out.println("Invalid input. Please enter a number.");
                    input.nextLine();
                    
                    System.out.print("Choose an option: ");
                }
                
                choice = input.nextInt();
                input.nextLine();
                
                switch (choice) {
                    case 1 -> {
                        User user = new User();
                        
                        System.out.print("Enter first name: ");
                        user.setFirstName(input.nextLine());
                        
                        System.out.print("Enter last name: ");
                        user.setLastName(input.nextLine());
                        
                        System.out.print("Enter username: ");
                        user.setUsername(input.nextLine());
                        
                        System.out.print("Enter password: ");
                        String registerPassword = input.nextLine();
                        
                        System.out.print("Enter phone number (+27...): ");
                        user.setPhoneNumber(input.nextLine());
                        
                        // Register user
                        String registrationResult =
                                login.registerUser(user, registerPassword);
                        
                        System.out.println(registrationResult);
                    }
                    case 2 -> {
                        System.out.print("Enter username: ");
                        String username = input.nextLine();
                        
                        System.out.print("Enter password: ");
                        String loginPassword = input.nextLine();
                        
                        // Attempt login
                        User loggedInUser =
                                login.loginUser(username, loginPassword);
                        
                        System.out.println(
                                login.loginMessage(loggedInUser)
                        );
                        
                        // Continue only if login successful
                        if (loggedInUser != null) {
                            
                            System.out.println(
                                    "\nYou are now logged in to QuickChat."
                            );
                            
                            System.out.print(
                                    "How many messages would you like to send? "
                            );
                            
                            int messageLimit = input.nextInt();
                            input.nextLine();
                            
                            int messageCount = 0;
                            
                            // Chat Menu Loop
                            while (messageCount < messageLimit) {
                                
                                System.out.println("\nQuickChat Menu");
                                System.out.println("1. Send Message");
                                System.out.println("2. Discard Message");
                                System.out.println("3. Store Message");
                                System.out.println("4. Exit Chat");
                                System.out.print("Choose an option: ");
                                
                                // Validate menu input
                                while (!input.hasNextInt()) {
                                    System.out.println(
                                            "Invalid input. Please enter a number."
                                    );
                                    
                                    input.nextLine();
                                    
                                    System.out.print("Choose an option: ");
                                }
                                
                                int chatOption = input.nextInt();
                                input.nextLine();
                                
                                // Exit chat
                                if (chatOption == 4) {
                                    System.out.println("Exiting chat...");
                                    break;
                                }
                                
                                // Message details
                                System.out.print(
                                        "Enter recipient phone number (+27...): "
                                );
                                
                                String recipient =
                                        input.nextLine();
                                
                                System.out.print("Enter your message: ");
                                String messageText =
                                        input.nextLine();
                                
                                // Create Message Object
                                Message message =
                                        new Message(
                                                messageCount + 1,
                                                recipient,
                                                messageText
                                        );
                                
                                // Message Actions
                                switch (chatOption) {
                                    
                                    case 1 -> System.out.println(
                                                message.sendMessage()
                                        );
                                        
                                    case 2 -> System.out.println(
                                                message.discardMessage()
                                        );
                                        
                                    case 3 -> System.out.println(
                                                message.storeMessage()
                                        );
                                        
                                    default -> System.out.println(
                                                "Invalid chat option selected."
                                        );
                                }
                                
                                messageCount++;
                            }
                            
                            // Display Message Summary
                            System.out.println("\nMessages Sent:");
                            System.out.println(
                                    Message.printMessages()
                            );
                            
                            System.out.println(
                                    "Total Messages: "
                                            + Message.returnTotalMessages()
                            );
                        }
                    }
                    case 3 -> System.out.println("Goodbye!");
                    default -> System.out.println(
                                "Invalid menu option. Please try again."
                        );
                }
                // REGISTER
                // LOGIN
                // EXIT
                // INVALID OPTION
                                
            } while (choice != 3);
        }
    }
}
    



        
       

