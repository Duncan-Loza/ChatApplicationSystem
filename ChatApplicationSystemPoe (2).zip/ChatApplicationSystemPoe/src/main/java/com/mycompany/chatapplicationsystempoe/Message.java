/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapplicationsystempoe;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Message {

    private final int messageNumber;
    private final String recipient;
    private final String messageText;

    private final String messageID;
    private final String messageHash;

    private String status;

    private static int totalMessages = 0;
    private static final ArrayList<Message> sentMessages = new ArrayList<>();

    // CONSTRUCTOR 
    public Message(int messageNumber, String recipient, String messageText) {

        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;

        this.messageID = createMessageID();
        this.messageHash = createMessageHash();
    }

    // MESSAGE ID (STRING MANIPULATION) 
    private String createMessageID() {

        // simple ID using loop counter + random part
        String randomPart = String.valueOf((int)(Math.random() * 9000 + 1000));
        return messageNumber + randomPart;
    }

    public String getMessageID() {
        return messageID;
    }

    // MESSAGE HASH (STRING MANIPULATION)
    final String createMessageHash() {

        String safeText = (messageText == null || messageText.isBlank())
                ? "EMPTY"
                : messageText;

        String[] words = safeText.trim().split("\\s+");

        String first = words.length > 0 ? words[0] : "EMPTY";
        String last = words.length > 0 ? words[words.length - 1] : "EMPTY";

        return (messageID.substring(0, 2)
                + messageNumber
                + first
                + last).toUpperCase();
    }

    // SEND MESSAGE 
    public String sendMessage() {

        if (messageText.length() > 250) {
            return "Message exceeds 250 characters.";
        }

        totalMessages++;
        sentMessages.add(this);
        status = "SENT";

        return "Message sent successfully.";
    }

    // DISCARD MESSAGE 
    public String discardMessage() {

        status = "DISCARDED";
        return "Message discarded.";
    }

    // STORE MESSAGE (JSON FORMAT) 
    public String storeMessage() {

        status = "STORED";

        try (FileWriter file = new FileWriter("messages.json", true)) {

            file.write("{"
                    + "\"messageNumber\":\"" + messageNumber + "\","
                    + "\"messageID\":\"" + messageID + "\","
                    + "\"recipient\":\"" + recipient + "\","
                    + "\"message\":\"" + messageText + "\","
                    + "\"hash\":\"" + messageHash + "\","
                    + "\"status\":\"" + status + "\""
                    + "}\n");

        } catch (IOException e) {
            return "Error storing message.";
        }

        return "Message stored successfully.";
    }

    // PRINT MESSAGES 
    public static String printMessages() {

        if (sentMessages.isEmpty()) {
            return "No messages sent yet.";
        }

        StringBuilder sb = new StringBuilder();

        // for loop 
        for (int i = 0; i < sentMessages.size(); i++) {

            Message m = sentMessages.get(i);

            sb.append("\nMessage #").append(m.messageNumber);
            sb.append("\nID: ").append(m.messageID);
            sb.append("\nRecipient: ").append(m.recipient);
            sb.append("\nMessage: ").append(m.messageText);
            sb.append("\nHash: ").append(m.messageHash);
            sb.append("\nStatus: ").append(m.status);
            sb.append("\n----------------------\n");
        }

        return sb.toString();
    }

    // TOTAL MESSAGES -
    public static int returnTotalMessages() {
        return totalMessages;
    }
}
