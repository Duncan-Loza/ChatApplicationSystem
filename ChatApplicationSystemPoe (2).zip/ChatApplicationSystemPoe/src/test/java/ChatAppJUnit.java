/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

package com.mycompany.chatapplicationsystempoe;

import java.util.ArrayList;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;

public class ChatAppJUnit {

    private final ArrayList<User> users = new ArrayList<>();

    // REGISTER USER
    public String registerUser(User user, String password) {

        if (!checkUsername(user.getUsername())) {
            return "Username must contain '_' and be max 5 characters long.";
        }

        if (!checkPassword(password)) {
            return "Password must be at least 8 characters, include a capital letter, a number and a special character.";
        }

        if (!user.getPhoneNumber().matches("^\\+27[6-8][0-9]{8}$")) {
            return "Phone number format is invalid. Must start with +27.";
        }

        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(user.getUsername())) {
                return "Username already exists.";
            }
        }

        user.setPasswordHash(hash(password));
        users.add(user);

        // ✅ FIXED (matches JUnit test exactly)
        return "Registration successful.";
    }

    // LOGIN USER
    public User loginUser(String username, String password) {

        String hashed = hash(password);

        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(username)
                    && u.getPasswordHash().equals(hashed)) {
                return u;
            }
        }

        return null;
    }

    public String loginMessage(User user) {
        return (user != null)
                ? "Welcome " + user.getFirstName() + ", you are logged in."
                : "Login failed. Incorrect username or password.";
    }

    private boolean checkUsername(String username) {
        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    private boolean checkPassword(String password) {

        if (password == null || password.length() < 8) return false;

        boolean upper = false, digit = false, special = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) upper = true;
            else if (Character.isDigit(c)) digit = true;
            else if (!Character.isLetterOrDigit(c)) special = true;
        }

        return upper && digit && special;
    }

    private String hash(String password) {

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");

            byte[] hashed = md.digest(password.getBytes(StandardCharsets.UTF_8));

            StringBuilder sb = new StringBuilder();

            for (byte b : hashed) {
                sb.append(String.format("%02x", b));
            }

            return sb.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error hashing password.");
        }
    }
}